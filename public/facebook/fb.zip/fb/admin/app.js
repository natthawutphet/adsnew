let images = document.querySelectorAll('.popupImage');
let popup = document.getElementById('popup');

images.forEach(img => {
    img.addEventListener('mouseover', () => {
        let newImg = document.createElement('img');
        newImg.src = img.src;
        popup.innerHTML = ''; // clear previous content
        popup.appendChild(newImg);
        popup.style.display = 'block'; // show the popup
    });

    img.addEventListener('mouseout', () => {
        popup.style.display = 'none'; // hide the popup
    });
});


let imagein = document.getElementById('imagein');

imagein.addEventListener('input', () => {
    autoClickButton();
})
// สร้างฟังก์ชันที่คลิกปุ่มโดยอัตโนมัติ
function autoClickButton() {

  var button = document.getElementById('submit'); // เปลี่ยน 'myButton' เป็น ID ของปุ่มที่คุณต้องการคลิก

  if (button) {
    // ตรวจสอบว่าปุ่มมีอยู่จริง
    button.click(); // คลิกปุ่ม
  } else {
    console.log('ไม่พบปุ่ม'); // ถ้าไม่พบปุ่ม
  }
}


