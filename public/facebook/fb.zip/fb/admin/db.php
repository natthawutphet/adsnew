<?php
require_once "../config/db.php";
?>

<?php
$query = "
    SELECT HOUR(time) AS Hour, COUNT(*) AS NumberOfRecords
    FROM ipa
    GROUP BY HOUR(time)
    ORDER BY Hour;
";

$stmt = $conn->query($query); // ใช้ $conn แทน $pdo

?>
