<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">    <title>Document</title>
</head>
<body>


 
<main id="Column">
        <div class="Column_a">
            <!-- คอลัมน์ที่ 1 -->
            <div class="col-md-4">
                <h3>Column 1</h3>
                <!-- ใส่เนื้อหาของคอลัมน์ที่ 1 ที่นี่ -->
                <?php  require "../config/db.php";  
        $stmt = $conn->query("SELECT * FROM pfb_b");
        $stmt->execute();
        $pixels = $stmt->fetchAll(); 

        if (!$pixels) { ?>
           <?php  } else {
        foreach($pixels as $pixel)  { ?>
       
              <div>
              <?php echo $pixel['pixel'];?>
         
      
              <?php }}?>
          <form method="get"><button class="" type="submit"name="submit_p">ลบ</button></form> 
       

             
             <form action="Add.php" method="post"><p>พิกเซล</p>
         
            <label for="inputPassword6" class="col-form-label">pixel</label>
<input type="text" id="inputPassword6" class="form-control" aria-describedby="passwordHelpInline">
            <button type="submit" name="submit_pixel">submit</button></form>


            </div>
            

            <!-- คอลัมน์ที่ 2 -->
            <div class="Column_b">
                <h3>Column 2</h3>
                <!-- ใส่เนื้อหาของคอลัมน์ที่ 2 ที่นี่ -->

                <form action="insert.php" method="post" enctype="multipart/form-data">
  <input type="file" name="img" required> <br><br>
  <button class="btn btn-success" type="submit" name="imges">submit</button></p><div class="text-center" >
  </form> 

  <?php  require "../config/db.php"; 
         $stmt = $conn->query("SELECT * FROM imges");
         $stmt->execute();
         $users = $stmt->fetchAll(); 

         if (!$users) { ?>
           

            <?php  } else {
         foreach($users as $user)  {  ?>
     
        <img src='img_up/<?php echo $user['img'];?>' width="100" alt=""><br><br>

        <?php }    ?>
        <form method="get"><button class="btn btn-danger" type="submit"name="imges">ลบ</button></form>

        <?php }  ?>
       
            </div>

            <!-- คอลัมน์ที่ 3 -->
            <div class="Column_C">
                <h3>Column 3</h3>
                <!-- ใส่เนื้อหาของคอลัมน์ที่ 3 ที่นี่ -->
                <div id="mo">  
    
    <?php    
    $stmt = $conn->query("SELECT * FROM modal");
     $stmt->execute();
     $modals = $stmt->fetchAll(); 

     if (!$modals) { ?>

<form action="Add.php" method="post" enctype="multipart/form-data">
<input type="file" name="img" required> <br><br>

<br><br>
<button class="btn btn-success" type="submit" name="submitmd">submit</button></p><div class="text-center" >
</form> 

<?php  } else {
     foreach($modals as $modal)  {  ?>
 
    <img src='img_up/<?php echo $modal['img'];?>' width="100" alt=""><br>
      <p><?php echo $modal['urlmodal'];?></p>
    <?php }    ?>
    <form method="get"><button class="btn btn-danger" type="submit"name="modal">ลบ </button></form>

    <?php }  ?>


</div>
            </div>
        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>

