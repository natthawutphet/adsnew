<?php 
require "config/db.php";

$line = "line.php";

$_SESSION['uipa']=$_SERVER['REMOTE_ADDR'];
$uipa = $_SESSION['uipa'];



$check_email = $conn->prepare("SELECT uipa FROM ipa WHERE uipa = :uipa");
$check_email->bindParam(":uipa", $uipa);
$check_email->execute();
$row = $check_email->fetch(PDO::FETCH_ASSOC);

if ($row['uipa'] == $uipa) {
  
} else {
   $uipa=$_SERVER['REMOTE_ADDR'];
   $referrer = $_SERVER['HTTP_REFERER'];
   
   $sql = $conn->prepare("INSERT INTO ipa(uipa, referrer) VALUES(:uipa, :referrer)");
   $sql->bindParam(":uipa", $uipa);
   $sql->bindParam(":referrer", $referrer);
   $sql->execute();

}

$stmt = $conn->query("SELECT * FROM modal");
$stmt->execute();
$modal = $stmt->fetchAll(); 
 
if(!$modal){ ?>
 <style>
  section {
    display: none;
  }
  header {
    display: block;
  }
</style>
  
  
  
  <?php
} else {
foreach($modal as $mo){
$m = $mo['home'];
if($m==1){ ?>
 <style>
  section {
    display: block;
  }
  header {
    display: none;
  }
</style>

<?php
}
}
}

?>



<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <title>ตุ๊กตาม้าโพนี่สุดโด่งดัง 

    </title>

   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
   
    <?php 
$stmt = $conn->query("SELECT * FROM cimg");
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);
   
   $BG = $row['img'];
   ?>
   
   
   <style>
    header{
        background:url('admin/BG/<?php echo $BG;?>');
        background-attachment: fixed;
       
    }
    .imgurl {
      max-width: 600px;
      margin: auto;
    }
     img {
      padding: 15px;
    }



</style>
<style>
   .logo {
    width: 100px; /* ขนาดรูปภาพตามที่คุณต้องการ */
    animation: tilt 10s ease-in-out infinite; /* รูปภาพจะเอียงไปและกลับมาตลอดเวลา */
}

@keyframes tilt {
    0%, 100% {
        transform: perspective(600px) rotateY(0deg);
    }
    50% {
        transform: perspective(600px) rotateY(-180deg);
    }
}
/*---------------------*/
.image-container {
    width: 100%; /* ขนาดรูปภาพตามที่คุณต้องการ */
  
    overflow: hidden; /* ปิดการแสดงผลนอกเขตของรูปภาพ */
}

.image-container img {
    width: 100%;

    animation: slideDown 2s ease-in-out forwards; /* รูปภาพจะเริ่มด้านบนและลดลงมา */
}

@keyframes slideDown {
    0% {
        transform: translateY(-100%);
    }
    100% {
        transform: translateY(0);
    }
}

.logo img {
    width: 300px;
    
}



  </style>
  

<?php 
$stmt = $conn->query("SELECT * FROM pfb_b");
$stmt->execute();
$pxs = $stmt->fetchAll(); 

 if(!$pxs){ 
 }else{  
  foreach($pxs as $px)  { 

   ?>


<?php echo $px['pixel']; } }?>
  </head>
  <body>
<!----------------------------------Modal---------------------------------------------------->
<?php  require "config/db.php"; 
         $stmt = $conn->query("SELECT * FROM logos");
         $stmt->execute();
         $users = $stmt->fetchAll(); 

         if (!$users) { ?>
           

            <?php  } else {
         foreach($users as $user)  {  ?>
        <?php }    ?>
<?php }  ?>

<header>
<div class=" text-center" > 
   <a href="web.php">
<img class="logo" src="admin/img_up/<?php echo $user['imglg'];?>" alt="Image"></div>


      
                    <div class="container"> 
                  <div class="img w-100 mx-auto">
            
                  <div class="image-container">
<?php  require "config/db.php"; 
         $stmt = $conn->query("SELECT * FROM imges");
         $stmt->execute();
         $users = $stmt->fetchAll(); 

         if (!$users) { ?>
           

            <?php  } else {
         foreach($users as $user)  {  ?>
     <a href="<?php echo $line;?>">
     <div class="imgurl">   
        <img src='admin/img_up/<?php echo $user['img'];?>'class="imge p-2" width="100%" alt="">
        </div>
      </a>

<?php } } ?>
            </div>
            </div>


        </div>
    </header>


<section>  

<div class="comtainer">
  <div class="text-center">
    <h1>ร้าน ตุ๊กตา สวยๆ</h1>
 
<p>ตุ๊กตาม้าโพนี่สุดโด่งดัง เนื้อสัมผัสนุ่มเย็นสบาย กอดนุ่มมากๆ<br>
สำหรับโพนีตัวใหญ่ขนาด 80cm และ 100cm จะสามารถนั่งหรือนอนกอดได้สบายเลยจ้า <br>
เหมาะสำหรับตกแต่งบ้าน แต่งร้าน ให้เป็นของขวัญสุดเซอร์ไพรส์<br>
สามารถกอดนอนเป็นหมอนข้างได้ หรือจะเป็นหมอนไว้หนุนก็นุ่มสบาย
คุณภาพดี รายละเอียดดีมากตามภาพเลยจ้า
คนรักน้องโพนี่ห้ามพลาดเชียว!
โปรโมชั่น! ราคาพิเศษ : 590.00 บาท</p>
<img src="i/product_shop_15390969131.jpg" alt="">
<img src="i/product_shop_15390969132.jpg" alt="">
<img src="i/product_shop_1539096914.jpg" alt="">
<img src="i/product_shop_15390969142.jpg" alt="">
<img src="i/product_shop_1557932578.jpg" alt="">
<img src="i/product_shop_15579325781.jpg" alt="">
<img src="i/product_shop_1557932674.jpg" alt="">
<img src="i/product_shop_1578931718.jpg" alt="">
<img src="i/product_shop_1578931813.jpg" alt="">


</div>
</div>

</section>



    
<div class="fixed-bottom">
<div class="text-center p-2">  

<a href="<?php echo $line;?>" class="btn btn-success w-50 rounded-pill ">  > >สมัครสมาชิก < <</a>
</div>


   </div>
   </div></div>

   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>

<script src="modal/modal.js"></script>

  
</body>
</html>
