const urls = '';

var referrer = document.referrer;
console.log(referrer);
const url = 'https://pgv9.co/';

if(referrer===url){
window.location=urls;
}